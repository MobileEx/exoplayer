/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.google.android.exoplayer2.gldemo;

public final class BuildConfig {
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  public static final String APPLICATION_ID = "com.google.android.exoplayer2.gldemo";
  public static final String BUILD_TYPE = "debug";
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 2011004;
  public static final String VERSION_NAME = "2.11.4";
}
